@echo off
chcp 65001 >nul
title Urania AI Beta 1.0 - Yayınlama
echo Urania AI Beta 1.0 yayınlama yardımcısı
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js bulunamadı. Önce https://nodejs.org adresinden LTS sürümünü kur.
 pause
 exit /b
)
call npm install
if errorlevel 1 (echo Kurulum başarısız. İnternet bağlantını kontrol et.& pause & exit /b)
call npx wrangler login
if errorlevel 1 (echo Cloudflare girişi tamamlanamadı.& pause & exit /b)
call npx wrangler deploy
echo.
echo Başarılı olursa terminalde workers.dev ile biten bağlantı görünür.
pause
