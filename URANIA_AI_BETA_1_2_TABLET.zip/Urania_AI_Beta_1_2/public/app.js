const $ = s => document.querySelector(s);
const promptEl=$("#prompt"), chatEl=$("#chat"), welcomeEl=$("#welcome"), historyEl=$("#history");
let messages=[], chats=JSON.parse(localStorage.getItem("urania_chats")||"[]"), attachedText="";
const save=()=>localStorage.setItem("urania_chats",JSON.stringify(chats));
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderHistory(){historyEl.innerHTML="";chats.slice().reverse().forEach((c,i)=>{const b=document.createElement("button");b.textContent=c.title||"Yeni sohbet";b.onclick=()=>loadChat(chats.length-1-i);historyEl.append(b);});}
function draw(){welcomeEl.classList.add("hidden");chatEl.classList.remove("hidden");chatEl.innerHTML=messages.map(m=>`<div class="msg ${m.role}"><div class="avatar">${m.role==="user"?"◉":"✦"}</div><div class="bubble">${escapeHtml(m.content)}</div></div>`).join("");window.scrollTo(0,document.body.scrollHeight);}
function saveCurrent(){if(!messages.length)return;const title=messages.find(m=>m.role==="user")?.content.slice(0,42)||"Yeni sohbet";chats.push({title,messages});save();renderHistory();}
function newChat(){messages=[];attachedText="";$("#fileName").textContent="";chatEl.classList.add("hidden");chatEl.innerHTML="";welcomeEl.classList.remove("hidden");promptEl.value="";}
function loadChat(i){messages=chats[i].messages||[];draw();}
async function checkStatus(){try{const r=await fetch("/api/status");const d=await r.json();$("#dot").classList.toggle("on",d.ready);$("#statusText").textContent=d.ready?"Urania AI çevrimiçi":"Urania AI bağlantısı yok";}catch{$("#statusText").textContent="Sunucuya bağlanılamadı";}}
async function send(text){text=(text??promptEl.value).trim();if(!text)return; if(attachedText)text+="\n\n[Eklenen dosyanın içeriği]\n"+attachedText;attachedText="";$("#fileName").textContent="";promptEl.value="";messages.push({role:"user",content:text});draw();const typing=document.createElement("div");typing.className="typing";typing.textContent="Urania düşünüyor…";chatEl.append(typing);$("#send").disabled=true;
try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages,education:{grade:"7. Sınıf",subject:"Türkçe"}})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Bir hata oluştu");messages.push({role:"assistant",content:d.answer});}
catch(e){messages.push({role:"assistant",content:"Bağlantı sorunu: "+e.message+"\n\nBiraz sonra tekrar dene. Günlük ücretsiz kullanım sınırı dolmuş veya model geçici olarak meşgul olabilir."});}
typing.remove();$("#send").disabled=false;draw();saveCurrent();}
$("#send").onclick=()=>send();$("#newChat").onclick=newChat;
promptEl.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,150)+"px";});
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>send(b.textContent));
document.querySelectorAll(".study-action").forEach(b=>b.onclick=()=>{
 const mode=b.dataset.study;
 const prompts={
  "Konu anlatımı":"7. sınıf Türkçe öğretmenim ol. Bana bir Türkçe konusu seçerek seviyeme uygun, kısa ve anlaşılır konu anlatımı yap. Önce hangi konuyu çalışmak istediğimi sor; örnekler ve mini alıştırmalar kullan.",
  "10 soruluk test":"7. sınıf Türkçe seviyesinde 10 soruluk, kolaydan zora ilerleyen çoktan seçmeli bir test hazırla. Soruları TEK TEK sor; ben cevaplamadan doğru cevabı açıklama. Her cevabımdan sonra kısa açıklama ve puan ver.",
  "Yazılı provası":"7. sınıf Türkçe yazılı provası başlat. Sözcükte anlam, cümlede anlam, paragraf, fiiller, zarflar, yazım ve noktalama konularından karışık sorular sor. Soruları tek tek sor ve sonunda sonuçlarımı değerlendir.",
  "Efsane modu":"7. sınıf Türkçe EFSANE MODU başlat. Çok zor ama müfredata uygun sorular sor. Her seferinde yalnızca bir soru sor, cevabımı bekle, doğru ve yanlışlarımı adil şekilde puanla ve çözümünü açıkla."
 };
 send(prompts[mode]);
});
$("#file").onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>500000){alert("Dosya en fazla 500 KB olabilir.");return;}attachedText=await f.text();$("#fileName").textContent="Eklendi: "+f.name;};
$("#export").onclick=()=>{if(!messages.length){alert("Dışa aktarılacak sohbet yok.");return;}const txt=messages.map(m=>(m.role==="user"?"SEN":"URANIA")+":\n"+m.content).join("\n\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([txt],{type:"text/plain;charset=utf-8"}));a.download="urania-sohbet.txt";a.click();URL.revokeObjectURL(a.href);};
$("#voice").onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert("Sesle yazma bu tarayıcıda desteklenmiyor.");return;}const rec=new SR();rec.lang="tr-TR";rec.onresult=e=>{promptEl.value+=(promptEl.value?" ":"")+e.results[0][0].transcript;};rec.start();};
renderHistory();checkStatus();setInterval(checkStatus,10000);
