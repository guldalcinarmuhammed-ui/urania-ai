URANIA AI BETA 1.2 - GENEL AMAÇLI YAPAY ZEKÂ + 7. SINIF TÜRKÇE MODU

Bu paket Urania AI'nin internette açılabilen beta sürümüdür.
Arayüz Cloudflare Workers üzerinde yayınlanır; sohbet yanıtları Cloudflare Workers AI ile üretilir.
Ziyaretçilerin Ollama kurması gerekmez. Model: OpenAI gpt-oss-120b (Cloudflare Workers AI üzerinden sunulur). Bu, OpenAI tarafından yayımlanan açık ağırlıklı bir modeldir; ChatGPT uygulamasındaki GPT-6 ile aynı model değildir. Bu sürüm genel amaçlı sohbet, genel bilgi, matematik, bilim, tarih, teknoloji ve yazılım sorularına yanıt vermeyi hedefler. Ayrıca 7. sınıf Türkçe öğretmen modu, konu anlatımı, 10 soruluk test, yazılı provası ve Efsane Modu kısayolları bulunur. Model tek başına canlı internet araması yapmaz; güncel olayları kontrol ettiğini iddia etmez.

ÜCRETSİZ PLAN
Cloudflare Workers AI ücretsiz katmanında günlük 10.000 Neuron kullanım hakkı sunar. Limit ve uygunluk değişebilir.
Limit dolarsa o günkü yapay zekâ istekleri başarısız olabilir. Daha yüksek kullanım ücret gerektirebilir.
Bu projede ücretli plana otomatik geçiş yoktur. Ücretli yükseltme veya ödeme yöntemi ekleme.
Güncel fiyat: https://developers.cloudflare.com/workers-ai/platform/pricing/

WINDOWS'TA YAYINLAMA
1. ZIP dosyasını klasöre çıkart.
2. Node.js LTS kurulu değilse https://nodejs.org adresinden kur.
3. https://dash.cloudflare.com adresinden ücretsiz hesap aç veya giriş yap.
4. Bu klasörde YAYINLA.bat dosyasına çift tıkla.
5. Tarayıcı açılınca Cloudflare'a giriş yap ve izin ekranını onayla.
6. Komut penceresinde yayınlama tamamlanana kadar bekle.
7. Başarılı olursa terminalde workers.dev ile biten bir bağlantı görünür.
8. Bu bağlantıyı arkadaşlarınla paylaşabilirsin.

İLK KULLANIM
- İlk kullanımda Workers AI şartlarını kabul etmen istenebilir.
- AI binding wrangler.jsonc içinde AI adıyla tanımlıdır.
- AI binding eksikse Dashboard > Workers & Pages > urania-ai-beta-1 > Settings > Bindings bölümünden Workers AI ekle; değişken adı AI olsun ve yeniden deploy et.

GÜVENLİK VE SINIRLAR
- Basit istek limiti eklenmiştir. Herkese açmadan önce Cloudflare Dashboard > Security > WAF > Rate limiting bölümünde /api/chat için ek sınır koy.
- Sohbet mesajları yanıt üretmek için Cloudflare AI hizmetine gönderilir. Parola, adres, telefon, okul bilgisi veya özel belge gibi hassas bilgileri yazma.
- Bu beta sürümünde canlı internet araması, resim üretimi ve kullanıcı hesabı sistemi yoktur. Eğitim modu 7. sınıf Türkçe için hazırlanmıştır; diğer sınıf ve dersler sonraki sürümlerde eklenebilir.
- Sohbet geçmişi ziyaretçinin kendi tarayıcısında saklanır.
- Model yanlış yanıt verebilir; önemli bilgileri kontrol et.

YAYINI DURDURMA
Cloudflare Dashboard > Workers & Pages > urania-ai-beta-1 bölümünden Worker'ı silebilir veya durdurabilirsin.
