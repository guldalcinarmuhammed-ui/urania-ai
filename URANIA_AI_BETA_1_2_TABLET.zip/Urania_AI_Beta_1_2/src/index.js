const MODEL = "@cf/openai/gpt-oss-120b";
const buckets = new Map();
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}});}
function allowed(ip){const now=Date.now(),item=buckets.get(ip);if(!item||now-item.start>60000){buckets.set(ip,{start:now,count:1});return true;}if(item.count>=8)return false;item.count++;return true;}
export default {
 async fetch(request,env){
  const url=new URL(request.url);
  if(url.pathname==="/api/status"&&request.method==="GET")return json({ready:Boolean(env.AI),model:"OpenAI gpt-oss-120b",beta:"1.2"});
  if(url.pathname==="/api/chat"&&request.method==="POST"){
   const ip=request.headers.get("CF-Connecting-IP")||"unknown";
   if(!allowed(ip))return json({error:"Çok hızlı mesaj gönderiyorsun. Bir dakika bekleyip tekrar dene."},429);
   if(Number(request.headers.get("Content-Length")||0)>32000)return json({error:"Mesaj çok büyük."},413);
   let body;try{body=await request.json();}catch{return json({error:"İstek okunamadı."},400);}
   const incoming=Array.isArray(body.messages)?body.messages:[];
   if(!incoming.length||incoming.length>20)return json({error:"Sohbet mesajı sayısı geçersiz."},400);
   const education=body.education||{};
   const isTurkishGrade7=education.grade==="7. Sınıf"&&education.subject==="Türkçe";
   const basePrompt="Sen Urania AI adlı genel amaçlı, Türkçe konuşabilen güçlü bir yapay zekâ asistanısın. Bilim, tarih, matematik, teknoloji, sanat, günlük yaşam, yazılım ve eğitim dahil geniş bir konu yelpazesinde yardımcı ol. Kullanıcının sorusuna uygun ayrıntı seviyesinde, açık ve düzenli yanıt ver. Bilmediğin bilgileri uydurma; emin değilsen bunu belirt. Güncel bilgi gerektiğinde internet erişimin olmadığını açıkça söyle; internette arama yaptığını iddia etme. Adım adım çözüm gerektiğinde çözümü anlaşılır biçimde göster. Öğrenciyle konuşurken nazik, cesaretlendirici ve yaşına uygun ol. Güvenli olmayan veya zararlı taleplerde güvenli alternatif sun.";
   const tutorPrompt=" Ayrıca 7. sınıf Türkçe dersinde özel öğretmen gibi yardımcı ol: sözcükte anlam, cümlede anlam, paragraf, fiiller, zarflar, ek fiil, yazım kuralları, noktalama ve metin türlerini sade örneklerle açıkla. Test veya sınav istendiğinde soruları TEK TEK sor; öğrenci cevaplamadan doğru cevabı açıklama. Cevapları adil değerlendir, kısa gerekçe ver ve puanı açıkça göster. Yanlış cevap için öğrenciyi utandırma. Müfredat ayrıntısından emin değilsen kesin konuşma.";
   const messages=[{role:"system",content:basePrompt+(isTurkishGrade7?tutorPrompt:"")}];
   for(const m of incoming){const role=m?.role==="assistant"?"assistant":"user";const content=String(m?.content||"").slice(0,6000);if(content)messages.push({role,content});}
   try{
    const result=await env.AI.run(MODEL,{messages,max_tokens:1200,temperature:0.6});
    const answer=result?.response||result?.output_text||result?.result?.response;
    if(!answer)return json({error:"Model yanıt üretemedi. Biraz sonra tekrar dene."},502);
    return json({answer});
   }catch{return json({error:"Urania şu anda yanıt veremiyor. Günlük ücretsiz kullanım sınırı dolmuş veya model geçici olarak meşgul olabilir."},503);}
  }
  if(url.pathname.startsWith("/api/"))return json({error:"Bu API adresi bulunamadı."},404);
  return env.ASSETS.fetch(request);
 }
};
